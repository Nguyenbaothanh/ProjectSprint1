﻿using QuanLyQuanCoffee.DAO;
using QuanLyQuanCoffee.DTO;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLyQuanCoffee
{

	public partial class TableManager : Form
	{
		private Account loginAccount;

		public Account LoginAccount
		{
			get => loginAccount;
			set { loginAccount = value; ChangeAccount(loginAccount.Type); }
		}

		public TableManager(Account acc)
		{
			InitializeComponent();
			this.LoginAccount = acc;

			LoadTable();
			LoadCategory();


			//LoadFoodListByCategoryID();
		}

		#region     Method

		void ChangeAccount(int type)
		{
			adminToolStripMenuItem.Enabled = type == 1;
			thôngTinCáNhânToolStripMenuItem.Text += "(" + LoginAccount.DisplayName + ")";
		}

		void LoadCategory()
		{
			List<Category> listCategory = CategoryDAO.Instance.GetListCategory();
			cbCategory.DataSource = listCategory;
			cbCategory.DisplayMember = "Name";
		}

		void LoadFoodListByCategoryID(int id)
		{
			List<Food> listFood = FoodDAO.Instance.GetFoodByCategoryId(id);
			cbFood.DataSource = listFood;
			cbFood.DisplayMember = "Name";
		}
		void LoadTable()
		{
			flbTable.Controls.Clear();
			List<Table> tableList = TableDAO.Instance.LoadTableList();
			foreach (Table item in tableList)
			{
				Button btn = new Button() { Width = TableDAO.TableWidth, Height = TableDAO.TableHeigh };
				btn.Text = item.Name + Environment.NewLine + item.Status;
				btn.Click += btn_Click;
				btn.Tag = item;

				switch (item.Status)
				{
					case "TRỐNG":
						btn.BackColor = Color.AliceBlue;
						break;
					default:
						btn.BackColor = Color.LightPink; break;
				}

				flbTable.Controls.Add(btn);

			}

		}

		void ShowBill(int id)
		{
			lsvBill.Items.Clear();
			List<Menu> listBillInfo = MenuDAO.Instance.GetListMenuByTable(id);
			float totalPrice = 0;

			foreach (Menu item in listBillInfo)
			{
				ListViewItem lsvItem = new ListViewItem(item.FoodName.ToString());
				lsvItem.SubItems.Add(item.Count.ToString());
				lsvItem.SubItems.Add(item.Price.ToString());
				lsvItem.SubItems.Add(item.TotalPrice.ToString());
				totalPrice += item.TotalPrice;
				lsvBill.Items.Add(lsvItem);
			}
			CultureInfo culture = new CultureInfo("VI-vn");

			txbTotalPrice.Text = totalPrice.ToString("#,##0.00") + "đ";

		}

		#endregion


		#region Events
		void btn_Click(object sender, EventArgs e)
		{
			int tableID = ((sender as Button).Tag as Table).ID;
			lsvBill.Tag = (sender as Button).Tag;
			ShowBill(tableID);
		}
		private void đăngXuấtToolStripMenuItem_Click(object sender, EventArgs e)
		{
			this.Close();
		}

		private void thôngTinCáNhânToolStripMenuItem_Click(object sender, EventArgs e)
		{
			AccountProfile f = new AccountProfile(LoginAccount);
			f.UpdateAccount += f_updateAccount;

			f.ShowDialog();


		}

		void f_updateAccount(object sender, AccountEvent e)
		{
			thôngTinCáNhânToolStripMenuItem.Text = "Thông tin tài khoản (" + e.Acc.DisplayName + ")";
		}

		private void adminToolStripMenuItem_Click(object sender, EventArgs e)
		{
			Admin f = new Admin();
			f.loginAccount = LoginAccount;
			f.UpdateFood += f_InsertedFood;
			f.DeleteFood += f_DeleteFood;
			f.UpdateFood += f_UpdateFood;

			f.ShowDialog();
		}

		private void f_UpdateFood(object? sender, EventArgs e)
		{
			LoadFoodListByCategoryID((cbCategory.SelectedItem as Category).ID);
			if (lsvBill.Tag != null)
				ShowBill((lsvBill.Tag as Table).ID);
		}

		private void f_DeleteFood(object? sender, EventArgs e)
		{
			LoadFoodListByCategoryID((cbCategory.SelectedItem as Category).ID);
			if (lsvBill.Tag != null)
				ShowBill((lsvBill.Tag as Table).ID);
			LoadTable();
		}

		private void f_InsertedFood(object? sender, EventArgs e)
		{
			LoadFoodListByCategoryID((cbCategory.SelectedItem as Category).ID);
			if (lsvBill.Tag != null)
				ShowBill((lsvBill.Tag as Table).ID);
		}

		private void cbCategory_SelectedIndexChanged(object sender, EventArgs e)
		{
			int id = 0;

			ComboBox cb = sender as ComboBox;
			if (cb.SelectedItem == null)
				return;

			Category selected = cb.SelectedItem as Category;
			id = selected.ID;

			LoadFoodListByCategoryID(id);
		}

		private void btnAđdFood_Click(object sender, EventArgs e)
		{
			Table table = lsvBill.Tag as Table;

			if (table == null)
			{
				MessageBox.Show("Hãy chọn bàn");
				return;
			}

			int idBill = BillDAO.Instance.GetUncheckBillIDByTableID(table.ID);
			int foodID = (cbFood.SelectedItem as Food).ID;
			int count = (int)nmFoodCount.Value;

			if (idBill == -1)
			{
				BillDAO.Instance.InsertBill(table.ID);
				Bill_InfoDAO.Instance.InsertBillInfo(BillDAO.Instance.GetMaxIDBill(), foodID, count);
			}
			else
			{
				Bill_InfoDAO.Instance.InsertBillInfo(idBill, foodID, count);
			}
			ShowBill(table.ID);
			LoadTable();

		}

		private void btnCheckOut_Click(object sender, EventArgs e)
		{

			Table table = lsvBill.Tag as Table;
			int idBill = BillDAO.Instance.GetUncheckBillIDByTableID(table.ID);
			int discount = (int)nmDiscount.Value;

			double totalPrice = Convert.ToDouble(txbTotalPrice.Text.Split(',')[0].Replace(".", ""));
			double finalTotalPrice = (totalPrice - (totalPrice / 100) * discount) * 1000;

			if (idBill != -1)
			{
				if (MessageBox.Show(string.Format("Bạn có chắc thanh toán hóa đơn cho {0}\nTổng tiền - (Tổng tiền / 100) x Giảm giá\n ==> {1}" + ".000" + " - ({1}" + ".000" + "  / 100) x {2}  = {3}", table.Name, totalPrice, discount, finalTotalPrice.ToString("#,##0") + "đ"), "Thông báo", MessageBoxButtons.OKCancel) == System.Windows.Forms.DialogResult.OK)
				{
					BillDAO.Instance.CheckOunt(idBill, discount, (float)finalTotalPrice);
					ShowBill(table.ID);
					LoadTable();
				}
			}
		}


		void PrintBillByID(int id)
		{
			PrintDialog printDialog = new PrintDialog();
			PrintDocument printDocument = new PrintDocument();
			printDocument.PrintPage += PrintDocument_PrintPage;

			if (printDialog.ShowDialog() == DialogResult.OK)
			{
				printDocument.PrinterSettings.PrinterName =
				printDialog.PrinterSettings.PrinterName;

				printDocument.DefaultPageSettings.PaperSize =
				printDialog.PrinterSettings.PaperSizes[8];

				printDocument.DocumentName =
				$"BillID_{id}_" + DateTime.Now.ToString("ddMMyyy_hhmmss_tt");

				printDocument.Print();
			}
		}


		private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
		{
			Font fontBold = new Font(FontFamily.Families[159], 12, FontStyle.Bold); //font segoe UI
			Font fontRegular = new Font(FontFamily.Families[159], 9, FontStyle.Regular);

			string content = "**HOÁ ĐƠN THANH TOÁN**";
			e.Graphics.DrawString(content, fontBold, Brushes.Black, 300, 50);

			string pattern = @"\d+";
			var id = int.Parse(Regex.Match((sender as PrintDocument).DocumentName, pattern).Value);
			var bill = BillDAO.Instance.GetUncheckBillIDByTableID(id);

			content = $"Ngày:\t\t {DateTime.Now.ToString("F")}\nID hoá đơn:\t {id}";
			e.Graphics.DrawString(content, fontRegular, Brushes.Black, 192, 120);

			Bitmap bitmap = new Bitmap(lsvBill.Width, lsvBill.Height,
											  System.Drawing.Imaging.PixelFormat.Format32bppRgb);
			lsvBill.DrawToBitmap(bitmap, new Rectangle(0, 0, lsvBill.Width - 1, lsvBill.Height));

			e.Graphics.DrawImage(bitmap, new Point(192, 170));

			int discount = (int)nmDiscount.Value;
			double billTotalPrice = (double)txbTotalPrice.Tag;
			double billFinalPrice = billTotalPrice - billTotalPrice * discount / 100;
			System.Globalization.CultureInfo culture = new System.Globalization.CultureInfo("vi- vn");

			content = $"Thành tiền:\t {txbTotalPrice.Text}\nGiảm giá:\t {discount}%\nPhải trả:\t{billFinalPrice.ToString("c0", culture)}";
			e.Graphics.DrawString(content, fontBold, Brushes.Black, 192, 550);


		}
		#endregion

		private void TableManager_Load(object sender, EventArgs e)
		{

		}
	}
}
