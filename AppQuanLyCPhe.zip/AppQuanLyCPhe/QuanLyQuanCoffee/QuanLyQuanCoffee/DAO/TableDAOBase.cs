﻿using QuanLyQuanCoffee.DTO;

namespace QuanLyQuanCoffee.DAO
{
    public abstract class TableDAOBase
    {
        public abstract List<Table> LoadTableList();
    }
}