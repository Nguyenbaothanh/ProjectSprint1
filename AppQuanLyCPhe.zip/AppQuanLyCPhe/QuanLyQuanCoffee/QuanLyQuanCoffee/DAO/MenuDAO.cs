﻿using QuanLyQuanCoffee.DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyQuanCoffee.DAO
{
    public class MenuDAO
    {
        private static MenuDAO instance;

        public static MenuDAO Instance
        {
            get { if (instance == null) instance = new MenuDAO(); return instance; }
            private set => instance = value;
        }

        private MenuDAO() { }

        public List<Menu> GetListMenuByTable(int id) {
            List<Menu> listMenus = new List<Menu>();
            string query = "select f.name, bi.count, f.price, f.price*bi.count as totalPrice from dbo.BillInfo as bi, dbo.Bill as b, dbo.Food as f\r\nwhere bi.idBill = b.id and bi.idFood = f.id and b.status = 0 and b.idTableFood = "+ id;
            DataTable data = DataProvider.Instance.ExcuteQuery(query);

            foreach (DataRow item in data.Rows) {
                Menu menu = new Menu(item);
                listMenus.Add(menu);
            }
            return listMenus;

           
        }
    }
}
