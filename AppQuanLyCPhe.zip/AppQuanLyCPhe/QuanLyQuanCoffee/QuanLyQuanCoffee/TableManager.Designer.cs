﻿namespace QuanLyQuanCoffee
{
	partial class TableManager
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			menuStrip1 = new MenuStrip();
			adminToolStripMenuItem = new ToolStripMenuItem();
			thôngTinTàiKhoảnToolStripMenuItem = new ToolStripMenuItem();
			thôngTinCáNhânToolStripMenuItem = new ToolStripMenuItem();
			đăngXuấtToolStripMenuItem = new ToolStripMenuItem();
			panel2 = new Panel();
			lsvBill = new ListView();
			columnHeader1 = new ColumnHeader();
			columnHeader2 = new ColumnHeader();
			columnHeader3 = new ColumnHeader();
			columnHeader4 = new ColumnHeader();
			panel4 = new Panel();
			label2 = new Label();
			label1 = new Label();
			cbFood = new ComboBox();
			cbCategory = new ComboBox();
			nmFoodCount = new NumericUpDown();
			btnAddFood = new Button();
			panel3 = new Panel();
			txbTotalPrice = new TextBox();
			nmDiscount = new NumericUpDown();
			btnDiscount = new Button();
			btnCheckOut = new Button();
			flbTable = new FlowLayoutPanel();
			label3 = new Label();
			label4 = new Label();
			label5 = new Label();
			pictureBox1 = new PictureBox();
			pictureBox2 = new PictureBox();
			menuStrip1.SuspendLayout();
			panel2.SuspendLayout();
			panel4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nmFoodCount).BeginInit();
			panel3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)nmDiscount).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
			((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
			SuspendLayout();
			// 
			// menuStrip1
			// 
			menuStrip1.ImageScalingSize = new Size(20, 20);
			menuStrip1.Items.AddRange(new ToolStripItem[] { adminToolStripMenuItem, thôngTinTàiKhoảnToolStripMenuItem });
			menuStrip1.Location = new Point(0, 0);
			menuStrip1.Name = "menuStrip1";
			menuStrip1.Size = new Size(1269, 28);
			menuStrip1.TabIndex = 0;
			menuStrip1.Text = "menuStrip1";
			// 
			// adminToolStripMenuItem
			// 
			adminToolStripMenuItem.Name = "adminToolStripMenuItem";
			adminToolStripMenuItem.Size = new Size(67, 24);
			adminToolStripMenuItem.Text = "Admin";
			adminToolStripMenuItem.Click += adminToolStripMenuItem_Click;
			// 
			// thôngTinTàiKhoảnToolStripMenuItem
			// 
			thôngTinTàiKhoảnToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { thôngTinCáNhânToolStripMenuItem, đăngXuấtToolStripMenuItem });
			thôngTinTàiKhoảnToolStripMenuItem.Name = "thôngTinTàiKhoảnToolStripMenuItem";
			thôngTinTàiKhoảnToolStripMenuItem.Size = new Size(151, 24);
			thôngTinTàiKhoảnToolStripMenuItem.Text = "Thông tin tài khoản";
			// 
			// thôngTinCáNhânToolStripMenuItem
			// 
			thôngTinCáNhânToolStripMenuItem.Name = "thôngTinCáNhânToolStripMenuItem";
			thôngTinCáNhânToolStripMenuItem.Size = new Size(210, 26);
			thôngTinCáNhânToolStripMenuItem.Text = "&Thông tin cá nhân";
			thôngTinCáNhânToolStripMenuItem.Click += thôngTinCáNhânToolStripMenuItem_Click;
			// 
			// đăngXuấtToolStripMenuItem
			// 
			đăngXuấtToolStripMenuItem.Name = "đăngXuấtToolStripMenuItem";
			đăngXuấtToolStripMenuItem.Size = new Size(210, 26);
			đăngXuấtToolStripMenuItem.Text = "&Đăng Xuất";
			đăngXuấtToolStripMenuItem.Click += đăngXuấtToolStripMenuItem_Click;
			// 
			// panel2
			// 
			panel2.Controls.Add(lsvBill);
			panel2.Location = new Point(440, 31);
			panel2.Name = "panel2";
			panel2.Size = new Size(406, 508);
			panel2.TabIndex = 2;
			// 
			// lsvBill
			// 
			lsvBill.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4 });
			lsvBill.Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
			lsvBill.GridLines = true;
			lsvBill.Location = new Point(3, 3);
			lsvBill.Name = "lsvBill";
			lsvBill.Size = new Size(403, 502);
			lsvBill.TabIndex = 0;
			lsvBill.UseCompatibleStateImageBehavior = false;
			lsvBill.View = View.Details;
			// 
			// columnHeader1
			// 
			columnHeader1.Text = "Tên Món";
			columnHeader1.Width = 150;
			// 
			// columnHeader2
			// 
			columnHeader2.Text = "Số Lượng";
			columnHeader2.Width = 80;
			// 
			// columnHeader3
			// 
			columnHeader3.Text = "Đơn Gía";
			columnHeader3.Width = 80;
			// 
			// columnHeader4
			// 
			columnHeader4.Text = "Thành Tiền";
			columnHeader4.Width = 80;
			// 
			// panel4
			// 
			panel4.Controls.Add(label2);
			panel4.Controls.Add(label1);
			panel4.Controls.Add(cbFood);
			panel4.Controls.Add(cbCategory);
			panel4.Location = new Point(860, 31);
			panel4.Name = "panel4";
			panel4.Size = new Size(400, 228);
			panel4.TabIndex = 1;
			// 
			// label2
			// 
			label2.AutoSize = true;
			label2.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
			label2.Location = new Point(-3, 144);
			label2.Name = "label2";
			label2.Size = new Size(111, 19);
			label2.TabIndex = 3;
			label2.Text = "Chọn sản phẩm";
			// 
			// label1
			// 
			label1.AutoSize = true;
			label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
			label1.Location = new Point(3, 39);
			label1.Name = "label1";
			label1.Size = new Size(104, 19);
			label1.TabIndex = 2;
			label1.Text = "Loại mặt hàng";
			// 
			// cbFood
			// 
			cbFood.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			cbFood.FormattingEnabled = true;
			cbFood.Location = new Point(158, 139);
			cbFood.Name = "cbFood";
			cbFood.Size = new Size(226, 30);
			cbFood.TabIndex = 1;
			// 
			// cbCategory
			// 
			cbCategory.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			cbCategory.FormattingEnabled = true;
			cbCategory.Location = new Point(158, 34);
			cbCategory.Name = "cbCategory";
			cbCategory.Size = new Size(226, 30);
			cbCategory.TabIndex = 0;
			cbCategory.SelectedIndexChanged += cbCategory_SelectedIndexChanged;
			// 
			// nmFoodCount
			// 
			nmFoodCount.Location = new Point(20, 47);
			nmFoodCount.Minimum = new decimal(new int[] { 100, 0, 0, int.MinValue });
			nmFoodCount.Name = "nmFoodCount";
			nmFoodCount.Size = new Size(159, 30);
			nmFoodCount.TabIndex = 3;
			nmFoodCount.TextAlign = HorizontalAlignment.Center;
			nmFoodCount.Value = new decimal(new int[] { 1, 0, 0, 0 });
			// 
			// btnAddFood
			// 
			btnAddFood.Location = new Point(20, 94);
			btnAddFood.Name = "btnAddFood";
			btnAddFood.Size = new Size(159, 39);
			btnAddFood.TabIndex = 2;
			btnAddFood.Text = "Thêm Món";
			btnAddFood.UseVisualStyleBackColor = true;
			btnAddFood.Click += btnAđdFood_Click;
			// 
			// panel3
			// 
			panel3.Controls.Add(nmFoodCount);
			panel3.Controls.Add(txbTotalPrice);
			panel3.Controls.Add(btnAddFood);
			panel3.Controls.Add(nmDiscount);
			panel3.Controls.Add(btnDiscount);
			panel3.Controls.Add(btnCheckOut);
			panel3.Location = new Point(860, 281);
			panel3.Name = "panel3";
			panel3.Size = new Size(406, 258);
			panel3.TabIndex = 3;
			// 
			// txbTotalPrice
			// 
			txbTotalPrice.Font = new Font("Arial", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
			txbTotalPrice.ForeColor = Color.Red;
			txbTotalPrice.Location = new Point(20, 154);
			txbTotalPrice.Name = "txbTotalPrice";
			txbTotalPrice.ReadOnly = true;
			txbTotalPrice.Size = new Size(364, 27);
			txbTotalPrice.TabIndex = 7;
			txbTotalPrice.Text = "0";
			txbTotalPrice.TextAlign = HorizontalAlignment.Right;
			// 
			// nmDiscount
			// 
			nmDiscount.Location = new Point(233, 47);
			nmDiscount.Name = "nmDiscount";
			nmDiscount.Size = new Size(151, 30);
			nmDiscount.TabIndex = 4;
			nmDiscount.TextAlign = HorizontalAlignment.Center;
			// 
			// btnDiscount
			// 
			btnDiscount.Font = new Font("Times New Roman", 9F, FontStyle.Regular, GraphicsUnit.Point);
			btnDiscount.Location = new Point(233, 94);
			btnDiscount.Name = "btnDiscount";
			btnDiscount.Size = new Size(151, 39);
			btnDiscount.TabIndex = 5;
			btnDiscount.Text = "Giảm Giá (%)";
			btnDiscount.UseVisualStyleBackColor = true;
			// 
			// btnCheckOut
			// 
			btnCheckOut.Font = new Font("Arial Narrow", 9F, FontStyle.Regular, GraphicsUnit.Point);
			btnCheckOut.Location = new Point(20, 203);
			btnCheckOut.Name = "btnCheckOut";
			btnCheckOut.Size = new Size(364, 45);
			btnCheckOut.TabIndex = 4;
			btnCheckOut.Text = "Thanh Toán";
			btnCheckOut.UseVisualStyleBackColor = true;
			btnCheckOut.Click += btnCheckOut_Click;
			// 
			// flbTable
			// 
			flbTable.AutoScroll = true;
			flbTable.Font = new Font("Times New Roman", 12F, FontStyle.Bold, GraphicsUnit.Point);
			flbTable.Location = new Point(0, 31);
			flbTable.Name = "flbTable";
			flbTable.Size = new Size(434, 456);
			flbTable.TabIndex = 4;
			// 
			// label3
			// 
			label3.AutoSize = true;
			label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			label3.Location = new Point(12, 493);
			label3.Name = "label3";
			label3.Size = new Size(67, 22);
			label3.TabIndex = 5;
			label3.Text = "Trống :";
			// 
			// label4
			// 
			label4.AutoSize = true;
			label4.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			label4.Location = new Point(12, 517);
			label4.Name = "label4";
			label4.Size = new Size(100, 22);
			label4.TabIndex = 6;
			label4.Text = "Có Người :";
			// 
			// label5
			// 
			label5.AutoSize = true;
			label5.BackColor = SystemColors.ActiveCaption;
			label5.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point);
			label5.Location = new Point(117, 493);
			label5.Name = "label5";
			label5.Size = new Size(0, 22);
			label5.TabIndex = 7;
			// 
			// pictureBox1
			// 
			pictureBox1.BackColor = SystemColors.ActiveCaption;
			pictureBox1.Location = new Point(175, 493);
			pictureBox1.Name = "pictureBox1";
			pictureBox1.Size = new Size(209, 22);
			pictureBox1.TabIndex = 8;
			pictureBox1.TabStop = false;
			// 
			// pictureBox2
			// 
			pictureBox2.BackColor = Color.LightCoral;
			pictureBox2.Location = new Point(175, 521);
			pictureBox2.Name = "pictureBox2";
			pictureBox2.Size = new Size(209, 22);
			pictureBox2.TabIndex = 9;
			pictureBox2.TabStop = false;
			// 
			// TableManager
			// 
			AutoScaleDimensions = new SizeF(10F, 24F);
			AutoScaleMode = AutoScaleMode.Font;
			ClientSize = new Size(1269, 548);
			Controls.Add(pictureBox2);
			Controls.Add(pictureBox1);
			Controls.Add(label5);
			Controls.Add(label4);
			Controls.Add(label3);
			Controls.Add(panel4);
			Controls.Add(flbTable);
			Controls.Add(panel3);
			Controls.Add(panel2);
			Controls.Add(menuStrip1);
			Font = new Font("Arial Narrow", 12F, FontStyle.Regular, GraphicsUnit.Point);
			MainMenuStrip = menuStrip1;
			Margin = new Padding(4);
			Name = "TableManager";
			StartPosition = FormStartPosition.CenterScreen;
			Text = "Phần mềm quản lý quán Coffee";
			Load += TableManager_Load;
			menuStrip1.ResumeLayout(false);
			menuStrip1.PerformLayout();
			panel2.ResumeLayout(false);
			panel4.ResumeLayout(false);
			panel4.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nmFoodCount).EndInit();
			panel3.ResumeLayout(false);
			panel3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)nmDiscount).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
			((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
			ResumeLayout(false);
			PerformLayout();
		}

		#endregion

		private MenuStrip menuStrip1;
		private ToolStripMenuItem adminToolStripMenuItem;
		private ToolStripMenuItem thôngTinTàiKhoảnToolStripMenuItem;
		private ToolStripMenuItem thôngTinCáNhânToolStripMenuItem;
		private Panel panel2;
		private Panel panel4;
		private Button btnAddFood;
		private ComboBox cbFood;
		private ComboBox cbCategory;
		private Panel panel3;
		private NumericUpDown nmFoodCount;
		private Button btnCheckOut;
		private FlowLayoutPanel flbTable;
		private NumericUpDown nmDiscount;
		private Button btnDiscount;
		private ToolStripMenuItem đăngXuấtToolStripMenuItem;
		private ListView lsvBill;
		private ColumnHeader columnHeader1;
		private ColumnHeader columnHeader2;
		private ColumnHeader columnHeader3;
		private ColumnHeader columnHeader4;
		private TextBox txbTotalPrice;
		private Label label1;
		private Label label2;
		private Label label3;
		private Label label4;
		private Label label5;
		private PictureBox pictureBox1;
		private PictureBox pictureBox2;
	}
}