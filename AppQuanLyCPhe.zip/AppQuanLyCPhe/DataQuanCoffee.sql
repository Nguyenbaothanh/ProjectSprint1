﻿CREATE Database QuanLyCoffee

USE QuanLyCoffee
GO

--FOOD
--TABLE
--FOODCategory
--Account
--Bill
--BillInfo

CREATE TABLE TableFood
(
	id INT IDENTITY PRIMARY KEY,
	name NVARCHAR(100) NOT NULL DEFAULT N'Chưa đặt tên',
	status NVARCHAR(100) NOT NULL DEFAULT N'TRỐNG'		--Empty//Alive


)
GO

CREATE TABLE Account
(
	UserName NVARCHAR(10)	PRIMARY KEY ,
	DisplayName NVARCHAR(100)	NOT NULL DEFAULT N'KHÁCH HÀNG', 
	PassWord NVARCHAR(100)	NOT NULL DEFAULT 0,
	Type INT NOT NULL DEFAULT 0 --1: ADMIN OR 0:Staff


)
GO

CREATE TABLE FoodCategory
(
	id INT IDENTITY PRIMARY KEY,
	name NVARCHAR(100)	NOT NULL DEFAULT N'Chưa đặt tên',
)
GO

create TABLE Food
(
	id INT IDENTITY PRIMARY KEY,
	name NVARCHAR(100)	NOT NULL DEFAULT N'Chưa đặt tên',
	idCategory INT NOT NULL,	
	price FLOAT NOT NULL DEFAULT 0

	FOREIGN KEY (idCategory) REFERENCES dbo.FoodCategory(id)
)
GO

CREATE TABLE Bill
(
	id INT IDENTITY PRIMARY KEY,
	DateCheckin DATE NOT NULL DEFAULT GETDATE(),
	DateCheckout DATE,
	idTableFood INT NOT NULL,
	status INT NOT NULL	DEFAULT 0, -- Complete pay or not
	
	FOREIGN KEY (idTableFood) REFERENCES dbo.TableFood(id)
)
GO

CREATE TABLE BillInfo
(
	id INT IDENTITY PRIMARY KEY,
	idBill INT NOT NULL,
	idFood INT NOT NULL,
	count INT NOT NULL DEFAULT 0

	FOREIGN KEY (idBill) REFERENCES dbo.Bill(id),
	FOREIGN KEY (idFood) REFERENCES dbo.Food(id)
	
)

--Insert dữ liệu Account

INSERT INTO	dbo.Account
	( UserName,
	DisplayName,
	PassWord,
	Type
	)
VALUES	(
		N'Admin1',
		N'Hoang',
		N'1',
		1

		)
INSERT INTO	dbo.Account
	( UserName,
	DisplayName,
	PassWord,
	Type
	)
VALUES	(
		N'Staff1',
		N'HoangStaff',
		N'1',
		0

		)
--Stored Procedure
go
CREATE PROC USP_GetAccountByUserName
@userName nvarchar(100)
AS
BEGIN
	SELECT * FROM dbo.Account WHERE UserName = @userName
END
GO

EXEC dbo.USP_GetAccountByUserName @userName = N'Admin1'
GO

--Dùng Stored Procedure cho Login
CREATE PROC USP_Login
@userName nvarchar(100), @passWord nvarchar(100)
AS
BEGIN
	SELECT * FROM dbo.Account WHERE UserName = @userName AND PassWord = @passWord
END
GO

SELECT * FROM dbo.TableFood
--Chạy dữ liệu bàn ăn có 10 bàn( thêm bàn )
DECLARE @i INT = 0

WHILE @i <= 10
BEGIN
	INSERT dbo.TableFood( name) VALUES (N'Bàn' + CAST(@i AS NVARCHAR(100)))
	SET @i = @i + 1
END
GO

--Stored Procedure cho TableFood

CREATE PROC USP_GetTableList
AS SELECT * FROM dbo.TableFood
GO

UPDATE dbo.TableFood SET status = N'Có Người' WHERE id = 5

EXEC dbo.USP_GetTableList
GO

--Thêm Category
INSERT dbo.FoodCategory (name )
VALUES (N'Hải Sản')

INSERT dbo.FoodCategory (name )
VALUES (N'Nông Sản')

INSERT dbo.FoodCategory (name )
VALUES (N'Lâm Sản')

INSERT dbo.FoodCategory (name )
VALUES (N'Nước')

--Thêm Thức Ăn
--1.Hải sản
INSERT dbo.Food(name, idCategory, price)
VALUES (N'Cua Biển Rang Muối',
		N'1',
		200000		
)

INSERT dbo.Food(name, idCategory, price)
VALUES (N'Mực một nắng nướng sa tế',
		N'1',
		120000		
)


INSERT dbo.Food(name, idCategory, price)
VALUES (N'Nghêu Hấp Sả',
		N'1',
		50000		
)

--2.Nông Sản
INSERT dbo.Food(name, idCategory, price)
VALUES (N'Vú Dê Nướng',
		N'2',
		80000		
)

INSERT dbo.Food(name, idCategory, price)
VALUES (N'Cơm Chiên Dương Châu',
		N'2',
		40000		
)

--3.Lâm Sản
INSERT dbo.Food(name, idCategory, price)
VALUES (N'Heo Rừng Nướng Muối Oứt',
		N'3',
		150000		
)

--4.Nước
INSERT dbo.Food(name, idCategory, price)
VALUES (N'Coffee',
		N'4',
		30000	
)
INSERT dbo.Food(name, idCategory, price)
VALUES (N'Trà Tắc',
		N'5',
		20000		
)

--Thêm Bill
--Bill 1
INSERT dbo.Bill(DateCheckin, DateCheckout, idTableFood,status)
VALUES (GETDATE(), NULL, 3, 0)

INSERT dbo.Bill(DateCheckin, DateCheckout, idTableFood,status)
VALUES (GETDATE(), NULL, 4, 0)

--Bill 2:
INSERT dbo.Bill(DateCheckin, DateCheckout, idTableFood,status)
VALUES (GETDATE(), NULL, 4, 0)

--Bill 3:
INSERT dbo.Bill(DateCheckin, DateCheckout, idTableFood,status)
VALUES (GETDATE(), GETDATE(), 5, 1)

--Thêm BillInfo
INSERT dbo.BillInfo(idBill,idFood,count)
values (1 --idBill
		,3--idFood
		,4--count
		)

INSERT dbo.BillInfo(idBill,idFood,count)
values (1 --idBill
		,5--idFood
		,1--count
		)

INSERT dbo.BillInfo(idBill,idFood,count)
values (2 --idBill
		,1--idFood
		,2--count
		)

		INSERT dbo.BillInfo(idBill,idFood,count)
values (2 --idBill
		,6--idFood
		,2--count
		)
INSERT dbo.BillInfo(idBill,idFood,count)
values (3 --idBill
		,5--idFood
		,2--count
		)
GO


--Hàm set
select f.name, bi.count, f.price, f.price*bi.count as totalPrice from dbo.BillInfo as bi, dbo.Bill as b, dbo.Food as f
where bi.idBill = b.id and bi.idFood = f.id and b.status= 0 and b.idTableFood = 3
go

--tạo produre cho bill
create proc USP_InsertBill
@idTableFood INT as
BEGIN
	INSERT dbo.Bill(DateCheckin, DateCheckout, idTableFood,status,discount)
	VALUES ( getdate(), null, @idTableFood, 0, 0)
END
GO

--Tạo produre cho BillInfo
CREATE PROC USP_InsertBillInfo
@idBill INT, @idFood INT, @count INT as
BEGIN
	insert dbo.BillInfo(idBill, idFood, count)
	values (@idBill, @idFood, @count)
end
go




ALTER PROC USP_InsertBillInfo
@idBill INT, @idFood INT, @count INT as
BEGIN
	DECLARE @isExitBillInfo int
	DECLARE  @foodCount int = 1

	select @isExitBillInfo = id, @foodCount = b.count  
	FROM dbo.BillInfo as b 
	where idBill = @idBill and idFood = @idFood

	if (@isExitBillInfo >0)
	begin
		declare @newCount int = @foodCount + @count
		if(@newCount >0)
			update dbo.BillInfo set count = @foodCount + @count Where idFood = @idFood
				
		else 
			DELETE dbo.BillInfo where idBill = @idBill and idFood = @idFood
	end 

	Else
	begin
		insert dbo.BillInfo (idBill, idFood, count)
		values (@idBill, @idFood, @count )
	end


end
go

CREATE PROC USP_UpdateAccount
@userName NVARCHAR(100), @displayName NVARCHAR(100), @password NVARCHAR(100), @newPassword NVARCHAR(100)
AS
BEGIN
	DECLARE @isRightPass INT = 0
	
	SELECT @isRightPass = COUNT(*) FROM dbo.Account WHERE USERName = @userName AND PassWord = @password
	
	IF (@isRightPass = 1)
	BEGIN
		IF (@newPassword = NULL OR @newPassword = '')
		BEGIN
			UPDATE dbo.Account SET DisplayName = @displayName WHERE UserName = @userName
		END		
		ELSE
			UPDATE dbo.Account SET DisplayName = @displayName, PassWord = @newPassword WHERE UserName = @userName
	end
END
GO


-- hàm trigger billInfo
 CREATE TRIGGER UTG_UdateBillInfo
 on dbo.BillInfo for insert, update
 as
 begin
	declare @idBill int
	select @idBill = idBill from Inserted

	declare @idTable int
	SELECT @idTable = idTableFood from dbo.Bill where id = @idBill and status = 0
	update dbo.TableFood Set status = N'Có Người' Where id = @idTable
end
 go

Create trigger UTG_UdateBill
 on dbo.Bill for update
 as
 begin 
	declare @idBill int
	select @idBill = id from Inserted
	declare @idTable int
	select @idTable = idTableFood from dbo.Bill where id = @idBill 
	
	declare @count int
	select @count = count (*) from dbo.Bill where idTableFood = @idTable and status = 0

	if(@count =0)
		UPDATE dbo.TableFood SET status = N'TRỐNG' Where id = @idTable


 end
 go

 alter table dbo.Bill
 add discount int
 
 update dbo.Bill set discount =0


 go


 

select max(id)from dbo.Bill

 SELECT * FROM dbo.TableFood
SELECT * FROM dbo.Bill
SELECT * FROM dbo.BillInfo
SELECT * FROM dbo.Food
 SELECT * FROM dbo.FoodCategory
 SELECT * FROM dbo.Account


 go

 
 
 --hàm update bill
 UPDATE dbo.Bill set status=1 where id = 1

 go
ALTER table dbo.Bill add totalPrice float

 delete dbo.Bill
 go

CREATE proc USP_GetListBillByDate
 @checkIn date, @checkOut date
 as
 begin
	 
	
	select t.name as [Tên Bàn], DateCheckin as [Ngày Vào], DateCheckout as [Ngày Ra], b.totalPrice as [Tổng Tiền] ,discount as [Giảm Gía]
	from dbo.Bill as b, dbo.TableFood as t
	where DateCheckin >= @checkIn and DateCheckout <= @checkOut and b.status = 1 and t.id = b.idTableFood 
end
go


select name from dbo.Food as f, dbo.BillInfo as bi where f.id = bi.idFood


SELECT * FROM dbo.Bill
SELECT * FROM dbo.BillInfo
SELECT * FROM dbo.Food
go

